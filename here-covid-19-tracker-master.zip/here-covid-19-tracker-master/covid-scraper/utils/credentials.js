/*
 * Copyright (C) 2020 HERE Europe B.V.
 * Licensed under MIT, see full license in LICENSE
 * SPDX-License-Identifier: MIT
 */

const spaceId = "INSERT_HERE_STUDIO_SPACE_ID"
const accessToken = "INSERT_HERE_ACCESS_TOKEN"
const secret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

module.exports = {
  spaceId,
  accessToken,
  secret,
}
